﻿using AAD_Teste.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System.Data.SqlClient;

namespace AAD_Teste.Controllers
{
    public class HomeController : Controller
    {
        SqlCommand com = new SqlCommand();
        SqlDataReader Dr;
        SqlConnection con = new SqlConnection();
        List<Funcionario> funcionarios = new List<Funcionario>();

        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
            con.ConnectionString = AAD_Teste.Properties.Resources.ConnectionString;
        }

        public IActionResult Index()
        {
            FetchDATA();
            return View(funcionarios);
        }

        private void FetchDATA()
        {
            if(funcionarios.Count > 0)
            {
                funcionarios.Clear();   
            }
            try
            {
                con.Open();
                com.Connection = con;
                com.CommandText = "SELECT TOP (1000) [NIF],[Nome],[Apelido],[DataNasc],[DataAdmissao],[Morada],[Email],[CPCP],[Localidade] FROM [AAD].[dbo].[Funcionario] Join CP on Funcionario.CPCP = Cp.CP";
                Dr = com.ExecuteReader();
                while (Dr.Read())
                {
                    funcionarios.Add(new Funcionario()
                    { NIF = Dr["NIF"].ToString()
                      ,Nome = Dr["Nome"].ToString()
                      ,Apelido = Dr["Apelido"].ToString()
                      ,DataNasc = Dr["DataNasc"].ToString()
                      ,DataAdmissao = Dr["DataAdmissao"].ToString()
                      ,Morada = Dr["Morada"].ToString()
                      ,Email = Dr["Email"].ToString()
                      ,CPCP = Dr["CPCP"].ToString()
                      ,Localidade = Dr["Localidade"].ToString()
                    });
                }
                con.Close();
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }


        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
