﻿using Microsoft.VisualBasic;

namespace AAD_Teste.Models
{
    public class Funcionario
    {
        public string NIF { get; set; }
        public string Nome { get; set; }
        public string Apelido { get; set; }
        public string DataNasc { get; set;}
        public string DataAdmissao { get; set; }

        public string Morada { get; set; }

        public string Email { get; set; }

        public string CPCP { get; set; }
        public string Localidade { get; set; }


    }
}
