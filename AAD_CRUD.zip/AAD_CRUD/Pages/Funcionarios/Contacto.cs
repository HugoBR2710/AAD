﻿namespace AAD_CRUD.Pages.Funcionarios
{
	public class Contacto
	{
		public int TipoContactoTCID { get; set; }
		public string DescTipoContacto { get; set; }
		public int Contactos { get; set; }

	}
}
